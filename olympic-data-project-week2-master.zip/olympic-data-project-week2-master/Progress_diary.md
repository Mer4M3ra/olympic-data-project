# Progress
## 27th May
in this lesson i finished work with less than 1 min left **but** in the end the work did not succesfully save so i ended up doing the work at home it was much easier as i alr knew the answers
