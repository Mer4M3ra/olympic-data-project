# Activity 3
## Activity 1
### Questions
1. How many columns are in the dataset?
2. Name 3 and explain what they represent?
3. what do the first 5 rows show?
### Answers
1. Total of **15** columnns in the dataset
2. The following columns "Name, Sex, Age" represent the information about the contestant
3. the first 5 rows show the "head"
## Activity 2
### Questions
1. What are the top 5 sports?
2. How many male vs female athletes?
### Answers
1. The top 5 sports are Athletics, Gymnastics, Swimming, Shooting, Cycling with the numbers of 38624, 26707, 23195, 1148, 10859 respectively
2. There are 196594 Males while the Females have 74522
## Activity 3
### Questions
1. Whats the average age?
2. whats the oldest and youngest athlete?
3. Are there any columns with missing or strange values?
### Answers
1. The average age of the athletes is around the age of 26
2. the oldest athlete is 97 yearsc old while the youngest being 10 years old
3. Yes there are but instead they are with NA
## Extension
### Questions
1. Research what three of the lesser known codes stand for, e.g. "URS", "GDR", "FRG"
### Answers
1. The word URS stands for the former soviet union
2. the word GDR stands for the german democratic republic
3. the word FRG stands for the federal republic of germany
## Reflection
### Questions
1. What’s one thing you learned about the Olympics dataset?
2. What did you find challenging in setting up or running Pandas?
3. What’s something you'd like to analyse next?
### Answers
1. something i learned about the olympics is that people by the ages of 10 have competed in the olympics
2. i found it really challenging to actually download pandas as it would always say "pip is not a command" or something by thos words
3. in the future i would like to analyse the popularity of music